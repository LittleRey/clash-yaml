"""Tests for execution simulator."""
