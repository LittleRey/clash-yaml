"""Tests for vibe.common.clock."""
