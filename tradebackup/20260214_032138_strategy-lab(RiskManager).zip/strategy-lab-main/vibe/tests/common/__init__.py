"""Tests for vibe.common package."""
