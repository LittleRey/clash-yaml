"""API module for trading bot health checks and metrics."""

__all__ = [
    "health",
]
