"""Core infrastructure module for trading bot."""

__all__ = [
    "service",
]
