"""Execution simulator module."""
