# COINTEGRATION - Cointegration


## Architectural problem

Real-time chart analysis needs deterministic updates per bar and explicit handling of warm-up periods. COINTEGRATION addresses this by implementing `Calculates the cointegration of two series using the Engle-Granger method.` with parameterized inputs and direct state progression.

## Design decision

This implementation favors streaming execution over batch recomputation. The trade-off is more attention to state initialization, but latency stays predictable when charts scale.

## API surface

### Functions

- `Calculates the cointegration of two series using the Engle-Granger method.`

### Parameters

| Parameter | Purpose |
|---|---|
| `series_a` | series float The first series. |
| `series_b` | series float The second series. |
| `period` | int The lookback period for the regression and ADF test. |

### Returns

- float The Augmented Dickey-Fuller test statistic for the residuals. A more negative value suggests stronger evidence of cointegration.

## Input configuration

| Input variable | Type | Configuration |
|---|---|---|
| `i_source1` | `input.source` | default: `close`, label: "Source 1" |
| `i_source2_ticker` | `input.symbol` | default: `"SPY"`, label: "SPY" |
| `i_period` | `input.int` | default: `20`, label: "Period" |

## Runtime profile

- Declared optimization: for performance and dirty data
- Streaming model: single-pass update on each new bar.
- Warm-up behavior: outputs can be unstable until enough samples satisfy `period`.
- Memory model: state is kept in Pine series context rather than external buffers.

## Trade-offs

Streaming logic keeps incremental cost stable, but initialization and edge-case handling become first-class concerns. That is a deliberate choice: predictable execution beats opaque recalculation spikes in live charts.

## Verification checklist

1. Open the script in TradingView and confirm it compiles under Pine Script v6.
2. Validate warm-up behavior on sparse data and short histories.
3. Compare output against a trusted reference implementation for the same parameters.
4. Confirm parameter bounds reject invalid values without silent fallback.

## References

- Source code: `indicators/statistics/cointegration.pine`
- Documentation file: `indicators/statistics/cointegration.md`
- GitHub source view: https://github.com/mihakralj/QuanTAlib/blob/main/indicators/statistics/cointegration.pine
- GitHub documentation view: https://github.com/mihakralj/QuanTAlib/blob/main/indicators/statistics/cointegration.md
