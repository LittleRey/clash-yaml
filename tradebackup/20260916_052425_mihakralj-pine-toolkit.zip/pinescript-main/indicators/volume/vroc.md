# VROC - Vroc


## Architectural problem

Real-time chart analysis needs deterministic updates per bar and explicit handling of warm-up periods. VROC addresses this by implementing `Calculates Volume Rate of Change` with parameterized inputs and direct state progression.

## Design decision

This implementation favors streaming execution over batch recomputation. The trade-off is more attention to state initialization, but latency stays predictable when charts scale.

## API surface

### Functions

- `Calculates Volume Rate of Change`

### Parameters

| Parameter | Purpose |
|---|---|
| `vol` | Volume series for rate of change calculation |
| `period` | Number of periods for comparison |
| `calc_type` | Calculation type: true for percentage, false for point change |

### Returns

- Volume Rate of Change value

## Input configuration

| Input variable | Type | Configuration |
|---|---|---|
| `i_period` | `input.int` | default: `12`, label: "Period" |
| `i_calc_type` | `input.string` | default: `"Point"`, label: "Point" |

## Runtime profile

- Declared optimization: for performance and dirty data
- Streaming model: single-pass update on each new bar.
- Warm-up behavior: outputs can be unstable until enough samples satisfy `period`.
- Memory model: state is kept in Pine series context rather than external buffers.

## Trade-offs

Streaming logic keeps incremental cost stable, but initialization and edge-case handling become first-class concerns. That is a deliberate choice: predictable execution beats opaque recalculation spikes in live charts.

## Verification checklist

1. Open the script in TradingView and confirm it compiles under Pine Script v6.
2. Validate warm-up behavior on sparse data and short histories.
3. Compare output against a trusted reference implementation for the same parameters.
4. Confirm parameter bounds reject invalid values without silent fallback.

## References

- Source code: `indicators/volume/vroc.pine`
- Documentation file: `indicators/volume/vroc.md`
- GitHub source view: https://github.com/mihakralj/QuanTAlib/blob/main/indicators/volume/vroc.pine
- GitHub documentation view: https://github.com/mihakralj/QuanTAlib/blob/main/indicators/volume/vroc.md
