# RV - Rv


## Architectural problem

Real-time chart analysis needs deterministic updates per bar and explicit handling of warm-up periods. RV addresses this by implementing `Calculates Realized Volatility using intraday data.` with parameterized inputs and direct state progression.

## Design decision

This implementation favors streaming execution over batch recomputation. The trade-off is more attention to state initialization, but latency stays predictable when charts scale.

## API surface

### Functions

- `Calculates Realized Volatility using intraday data.`

### Parameters

| Parameter | Purpose |
|---|---|
| `length` | The lookback period for smoothing the period volatilities (e.g., daily RVs). Default is 20. |
| `intradayTimeframe` | The lower timeframe string (e.g., "1", "5", "60") to sample for returns. Must be a lower timeframe than the chart. Default is "5". |
| `annualize` | Boolean to indicate if the volatility should be annualized. Default is true. |
| `annualPeriods` | Number of periods (of the main chart's timeframe) in a year for annualization. Default is 252 (assuming daily chart). |

### Returns

- float The Realized Volatility value.

## Input configuration

| Input variable | Type | Configuration |
|---|---|---|
| `i_length_rv` | `input.int` | default: `20`, label: "Smoothing Length" |
| `i_intraday_tf_rv` | `input.timeframe` | default: `"5"`, label: "5" |
| `i_annualize_rv` | `input.bool` | default: `true`, label: "Annualize Volatility" |
| `i_annualPeriods_rv` | `input.int` | default: `252`, label: "Annual Periods" |

## Runtime profile

- Declared optimization: not explicitly annotated in source comments.
- Streaming model: single-pass update on each new bar.
- Warm-up behavior: outputs can be unstable until enough samples satisfy `length`.
- Memory model: state is kept in Pine series context rather than external buffers.

## Trade-offs

Streaming logic keeps incremental cost stable, but initialization and edge-case handling become first-class concerns. That is a deliberate choice: predictable execution beats opaque recalculation spikes in live charts.

## Verification checklist

1. Open the script in TradingView and confirm it compiles under Pine Script v6.
2. Validate warm-up behavior on sparse data and short histories.
3. Compare output against a trusted reference implementation for the same parameters.
4. Confirm parameter bounds reject invalid values without silent fallback.

## References

- Source code: `indicators/volatility/rv.pine`
- Documentation file: `indicators/volatility/rv.md`
- GitHub source view: https://github.com/mihakralj/QuanTAlib/blob/main/indicators/volatility/rv.pine
- GitHub documentation view: https://github.com/mihakralj/QuanTAlib/blob/main/indicators/volatility/rv.md
