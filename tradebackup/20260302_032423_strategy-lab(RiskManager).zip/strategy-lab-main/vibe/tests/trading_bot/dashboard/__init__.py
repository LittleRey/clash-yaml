"""Tests for dashboard module."""
