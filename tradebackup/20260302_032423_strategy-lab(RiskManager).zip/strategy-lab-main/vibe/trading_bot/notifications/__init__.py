"""Discord notifications module."""
