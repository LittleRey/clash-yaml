"""Tests for vibe.common.models."""
