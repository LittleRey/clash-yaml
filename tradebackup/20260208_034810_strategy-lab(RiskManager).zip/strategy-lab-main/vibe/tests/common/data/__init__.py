"""Tests for vibe.common.data."""
