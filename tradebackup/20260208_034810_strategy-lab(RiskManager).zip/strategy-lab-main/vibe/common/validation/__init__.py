"""
Validation utilities and rules.
"""

__all__ = []
