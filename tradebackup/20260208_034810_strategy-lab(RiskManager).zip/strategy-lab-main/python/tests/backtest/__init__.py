"""Backtest engine and trade manager tests package."""
