"""
Cloud Storage Providers - Implementations for various cloud platforms
"""

from ..storage_provider import CloudStorageProvider
