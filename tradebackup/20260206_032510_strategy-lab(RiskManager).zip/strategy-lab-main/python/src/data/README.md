# yfinance

* The requested range of 5m data must be within the last 60 days.