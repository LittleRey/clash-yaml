"""Snapshot-related tests package."""
