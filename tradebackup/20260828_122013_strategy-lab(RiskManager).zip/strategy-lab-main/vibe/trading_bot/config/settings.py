"""Configuration settings for trading bot using Pydantic."""

from typing import Optional, List
from pydantic_settings import BaseSettings
from pydantic import Field


class TradingSettings(BaseSettings):
    """Trading configuration."""

    market_type: str = Field(default="stocks", description="Market type (stocks, forex, crypto)")
    exchange: str = Field(default="NYSE", description="Exchange name (for stocks: NYSE, NASDAQ, etc.)")
    symbols: List[str] = Field(default=["AAPL", "GOOGL", "MSFT"], description="Trading symbols")
    initial_capital: float = Field(default=10000.0, description="Initial capital in USD")
    max_position_size: float = Field(default=0.1, description="Max position size as % of capital")
    use_stop_loss: bool = Field(default=True, description="Enable stop loss")
    stop_loss_pct: float = Field(default=0.02, description="Stop loss percentage")
    take_profit_pct: float = Field(default=0.05, description="Take profit percentage")

    class Config:
        env_prefix = ""
        case_sensitive = False


class DataSettings(BaseSettings):
    """Data provider configuration."""

    # Provider selection
    primary_provider: str = Field(default="finnhub", description="Primary data provider (interactive_brokers, polygon, finnhub, alpaca, yfinance)")
    secondary_provider: Optional[str] = Field(default=None, description="Secondary provider for fallback (optional)")

    # API keys
    finnhub_api_key: Optional[str] = Field(default=None, description="Finnhub API key for real-time intraday data")
    polygon_api_key: Optional[str] = Field(default=None, description="Polygon.io API key (recommended for production)")
    api_key: Optional[str] = Field(default=None, description="Generic API key (fallback)")

    # REST provider polling configuration
    poll_interval_with_position: int = Field(default=60, description="Poll interval in seconds when have open positions")
    poll_interval_no_position: int = Field(default=300, description="Poll interval in seconds when no positions (5 minutes)")

    # Legacy settings
    yahoo_rate_limit: int = Field(default=5, description="Yahoo Finance requests per second")
    yahoo_retry_count: int = Field(default=3, description="Yahoo Finance retry attempts")
    data_cache_ttl_seconds: int = Field(default=2592000, description="Cache TTL in seconds (30 days - historical data never changes)")
    bar_intervals: List[str] = Field(default=["1m", "5m", "15m"], description="Bar intervals to track")

    class Config:
        env_prefix = ""
        case_sensitive = False


class CloudSettings(BaseSettings):
    """Cloud storage configuration."""

    cloud_provider: Optional[str] = Field(default=None, description="Cloud provider (azure, aws)")
    cloud_container: Optional[str] = Field(default=None, description="Cloud storage container/bucket")
    sync_interval_seconds: int = Field(default=300, description="Cloud sync interval")
    enable_cloud_sync: bool = Field(default=False, description="Enable cloud sync")

    class Config:
        env_prefix = ""
        case_sensitive = False


class BrokerSettings(BaseSettings):
    """Broker configuration for paper/live execution."""

    broker_type: str = Field(default="mock", description="Broker backend (mock, interactive_brokers)")
    mode: str = Field(default="paper", description="Broker mode (paper, live)")
    ib_host: str = Field(default="127.0.0.1", description="IB TWS/Gateway host")
    ib_port: int = Field(default=4002, description="IB Gateway paper port 4002, live port 4001")
    ib_client_id: int = Field(default=1, description="IB client id")
    ib_account_id: Optional[str] = Field(default=None, description="IB account id")
    ib_exchange: str = Field(default="SMART", description="IB routing exchange")
    ib_currency: str = Field(default="USD", description="IB account/order currency")
    ib_market_data_type: int = Field(default=1, description="IB market data type: 1 live, 2 frozen, 3 delayed, 4 delayed frozen")
    ib_connect_timeout: float = Field(default=20.0, description="IB API connection timeout in seconds")
    ib_connect_max_retries: int = Field(default=3, description="Max IB API connection attempts before failing closed")
    ib_connect_retry_delay_seconds: float = Field(default=2.0, description="Delay between IB API connection retry attempts")
    health_check_enabled: bool = Field(default=True, description="Enable IB broker health checks during warmup")
    health_check_symbol: Optional[str] = Field(default=None, description="Symbol used for IB warmup quote validation")

    class Config:
        env_prefix = ""
        case_sensitive = False


class OperationalMetricsSettings(BaseSettings):
    """Operational execution metrics persistence settings."""

    enabled: bool = Field(default=True, description="Enable operational metrics recording")
    local_database_path: str = Field(default="./data/local/operational_metrics.db", description="Local metrics database path")
    remote_enabled: bool = Field(default=False, description="Enable remote cloud metrics writes")
    remote_provider: str = Field(default="supabase", description="Remote metrics provider")
    supabase_url: Optional[str] = Field(default=None, description="Supabase project URL")
    supabase_anon_key: Optional[str] = Field(default=None, description="Supabase anonymous key")
    supabase_table: str = Field(default="operational_metrics", description="Supabase table name")

    class Config:
        env_prefix = ""
        case_sensitive = False


class DashboardSettings(BaseSettings):
    """Live dashboard persistence and publication settings."""

    enabled: bool = Field(default=False, description="Enable dashboard persistence and publication")
    account_id: Optional[str] = Field(default=None, description="Phase 1 dashboard account ID")
    symbols: List[str] = Field(default=["AAPL", "GOOGL", "MSFT"], description="Symbols to persist for dashboard charts")
    price_timeframes: List[str] = Field(default=["5m", "1d"], description="Dashboard price bar timeframes")
    local_price_db_path: str = Field(default="./data/market_data.db", description="Local SQLite DB for dashboard price bars")
    local_dashboard_db_path: str = Field(default="./data/dashboard.db", description="Local SQLite DB for dashboard read-model rows")
    local_outbox_db_path: str = Field(default="./data/local/publish_outbox.db", description="Local SQLite DB for dashboard publish outbox")
    remote_provider: str = Field(default="supabase", description="Dashboard remote read-model provider")
    supabase_url: Optional[str] = Field(default=None, description="Supabase project URL")
    supabase_service_key: Optional[str] = Field(default=None, description="Bot-only Supabase service key")
    supabase_anon_key: Optional[str] = Field(default=None, description="Browser read-only Supabase anon key")
    publish_interval_seconds: int = Field(default=30, description="Dashboard publish batch interval")
    local_retention_days: int = Field(default=3, description="Local dashboard row retention window after publication")

    class Config:
        env_prefix = ""
        case_sensitive = False


class StrategySettings(BaseSettings):
    """Strategy configuration."""

    orb_start_time: str = Field(default="09:30", description="ORB window start time (HH:MM)")
    orb_duration_minutes: int = Field(default=5, description="ORB window duration in minutes")
    orb_body_pct_filter: float = Field(default=0.5, description="Minimum body percentage for valid breakout candle")
    entry_cutoff_time: str = Field(default="15:00", description="No entries after this time")
    take_profit_multiplier: float = Field(default=2.0, description="Take-profit = ORB_Range * multiplier")
    stop_loss_at_level: bool = Field(default=True, description="Stop-loss at ORB level (vs ATR-based)")
    use_volume_filter: bool = Field(default=False, description="Require above-average volume for breakout")
    volume_threshold: float = Field(default=1.5, description="Volume must be > average * threshold")
    market_close_time: str = Field(default="16:00", description="Market close time (HH:MM)")
    carryover_position_policy: str = Field(
        default="flatten_at_market_open",
        description="How to handle broker positions carried into a new session: flatten_at_market_open, block_new_entries, or manual_only",
    )

    class Config:
        env_prefix = ""
        case_sensitive = False


class NotificationSettings(BaseSettings):
    """Notification configuration."""

    discord_webhook_url: Optional[str] = Field(default=None, description="Discord webhook URL")
    notify_routine: bool = Field(
        default=True,
        description="Notify on routine operational events such as warmup, ORB, and daily summaries",
    )
    notify_on_trade: bool = Field(default=True, description="Notify on trade execution")
    notify_on_error: bool = Field(default=True, description="Notify on error")

    class Config:
        env_prefix = ""
        case_sensitive = False


class AppSettings(BaseSettings):
    """Main application settings combining all subsettings."""

    environment: str = Field(default="development", description="Environment (development/production)")
    log_level: str = Field(default="INFO", description="Logging level")
    health_check_port: int = Field(default=8080, description="Health check server port")
    shutdown_timeout_seconds: int = Field(default=30, description="Graceful shutdown timeout")
    database_path: str = Field(default="./data/trades.db", description="SQLite database path")
    active_ruleset: str = Field(
        default="orb_conservative",
        description="Name of the active ruleset file under vibe/rulesets/ (without .yaml)"
    )

    trading: TradingSettings = Field(default_factory=TradingSettings)
    data: DataSettings = Field(default_factory=DataSettings)
    strategy: StrategySettings = Field(default_factory=StrategySettings)
    cloud: CloudSettings = Field(default_factory=CloudSettings)
    broker: BrokerSettings = Field(default_factory=BrokerSettings)
    operational_metrics: OperationalMetricsSettings = Field(default_factory=OperationalMetricsSettings)
    dashboard: DashboardSettings = Field(default_factory=DashboardSettings)
    notifications: NotificationSettings = Field(default_factory=NotificationSettings)

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False
        env_nested_delimiter = "__"  # Enable reading nested fields like DATA__FINNHUB_API_KEY
        extra = "ignore"  # Allow backtester-only env vars to coexist in the shared .env


def get_settings() -> AppSettings:
    """Get application settings."""
    return AppSettings()
