"""Performance testing module for strategy-lab."""
