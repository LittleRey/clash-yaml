"""
Live data providers for trading bot.
"""

from .base import LiveDataProvider

__all__ = ["LiveDataProvider"]
