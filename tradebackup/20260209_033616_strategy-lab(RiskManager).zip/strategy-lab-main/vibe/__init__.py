"""
Vibe trading bot framework - shared components, trading bot, and backtester.
"""

__version__ = "0.1.0"
