"""Tests for vibe.common.execution."""
