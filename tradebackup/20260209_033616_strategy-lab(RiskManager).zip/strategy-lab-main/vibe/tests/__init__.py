"""Tests for vibe package."""
